﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player : MonoBehaviour {
    [SerializeField]
    private Rigidbody playerBody;
    private bool jump;
    private float inputX;
    private float inputZ;
    private Vector3 inputVector;

	// Use this for initialization
	void Start () {
        playerBody = GetComponent<Rigidbody>();	
	}
	
	// Update is called once per frame
	void Update () {
        //    playerBody.velocity = new Vector3(2f,playerBody.velocity.y,2f);
        //    print(Input.GetAxis("Horizontal"));
        //inputVector = new Vector3();
        inputVector = new Vector3(Input.GetAxis("Horizontal") * 10f, playerBody.velocity.y, Input.GetAxis("Vertical")*10f);
        transform.LookAt(transform.position + new Vector3(inputVector.x,0, inputVector.z));
        //
        if (Input.GetButtonDown("Jump"))
        {
            jump = true;
        }
    }
    private void FixedUpdate()
    {
        playerBody.velocity = inputVector;
        if (jump) {
            playerBody.AddForce(Vector3.up * 20f, ForceMode.Impulse);
            jump = false;
        }
    }
}

